// Set the deployed product origin here when RentZal goes online.
export const rentzal = {
  publicUrl: '',
  localUrl: 'http://localhost:5173',
};
